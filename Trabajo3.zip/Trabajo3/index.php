<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMC</title>
    <link rel="icon" href="icons/calculadora.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>
<body>
    <div class="container-lg bg-primary">
        <h1 class="text-white text-center p-2 m-2">Calculadora de IMC</h1>
        <h3 class="text-white text-center p-2 m-2">(Índice de masa corporal)</h3>
        <form class="bg-primary-subtle m-3 p-3" >
            
            <div class="mb-3 row">
                <label for="peso" class="col-sm-3 col-form-label text-primary">Peso (kg): </label>
                <div class="col-sm-9">
                    <input type="number" name="peso" id="peso" class="col-sm-3 col-form-label text-primary" value="0" step="0.0001"
                    required placeholder="0">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="altura" class="col-sm-3 col-form-label text-primary">Altura (m): </label>
                <div class="col-sm-9">
                    <input type="number" name="altura" id="altura" class="col-sm-3 col-form-label text-primary" value="0" step="0.0001"
                    required placeholder="0">
                </div>
            </div>
            
            <div class="mb-3 row">
                <button type="reset"  class="btn btn-warning col-sm-3 m-2 text-light" value="Borrar">Borrar</button>
                <button type="submit" class="btn btn-info col-sm-3 m-2 text-light" value="Calcular">Calcular</button>
            </div>

            <div class="mb-3 row">
                <label for="resultado" class="col-sm-3 col-form-label text-primary">IMC: </label>
                <div class="col-sm-4">
                    <div  class="form-control  text-primary" id="resultado"> 
                      <?php
                        include_once __DIR__. "../php/calculadora.php"; 
                        ?>
                    </div>
               </div>
            </div>
    </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>
</html>