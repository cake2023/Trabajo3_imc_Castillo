<?php

     $peso = $_REQUEST['peso'];
     $altura = $_REQUEST['altura'];

     function calcularImc(int $peso,int $altura ){
          if($peso!=0 && $altura!=0){
          $alturaMetros=$altura/100;
          $imc=$peso/($alturaMetros* $alturaMetros);
          return $imc;
          }else{
               echo "Valores inválidos<br>";
          }
     }

     function calcularEstado(float $imc){ 
          if($imc <= 15){
               return "Delgadez muy severa";
          } elseif( $imc > 15 && $imc < 15.9 ){
               return "Delgadez severa";
          } elseif( $imc >= 16 && $imc <= 18.4 ){
               return "Delgadez";
          } elseif( $imc > 18.5 && $imc < 24.9 ){
               return "Normal o Saludable";
          } elseif( $imc > 25 && $imc < 29.9 ){
               return "Sobrepeso";
          } elseif( $imc > 30 && $imc < 34.9 ){
               return "Obesidad moderada";
          } elseif( $imc > 35 && $imc < 39.9 ){
               return "Obesidad severa";
          } elseif( $imc >= 40 ){
               return "Obesidad mórbida";
          }
     }  

     $imc=calcularImc($peso,$altura);
     echo number_format($imc,2)."<br>";
     
     $estado=calcularEstado($imc); 
     echo $estado;
?>